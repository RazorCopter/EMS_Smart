// SPDX-License-Identifier: MIT
//
// Canonical device state. Every output adapter reads this and nothing else.

#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

#include "capability.h"
#include "device_identity.h"
#include "measurement.h"

namespace heliograph {

/// How many devices one bridge will poll, and the size of the state table that holds them.
///
/// Lives here rather than in the config or the state store because both need it and neither
/// should depend on the other. A bound, not a target: every device shares one half-duplex bus,
/// so each one added stretches the poll cycle by its own transaction time.
inline constexpr size_t kMaxDevices = 8;

/// Thresholds for the online/stale state machine. Defaults follow docs/architecture.md.
struct StalenessPolicy {
    uint32_t failuresBeforeStale   = 3;
    uint32_t failuresBeforeOffline = 10;
    uint64_t measurementMaxAgeMs   = 30000;
};

struct DeviceState {
    bool bridgeOnline   = false;
    bool inverterOnline = false;
    bool dataValid      = false;
    bool dataStale      = false;

    uint64_t lastPollAttemptMs    = 0;
    uint64_t lastSuccessfulPollMs = 0;
    uint32_t consecutiveFailures  = 0;

    DeviceIdentity       identity;
    /// What the operator calls this inverter ("Schuur"), from the configured device row.
    /// Empty means unlabelled, and every surface then shows the registered id, exactly as
    /// before the field existed.
    ///
    /// DISPLAY ONLY, and separate from `identity` on purpose. `identity` is what the device
    /// told us and it carries deviceId(), the key behind REST paths, MQTT topics and Home
    /// Assistant unique_ids. A label that leaked into any of those would move an operator's
    /// whole history the moment they renamed an inverter (#76).
    std::string          label;
    InverterCapabilities capabilities;
    MeasurementSet       measurements;

    uint16_t statusCode = 0;
    /// The same rule errorCodeSupported already carried, and for the same reason: not every
    /// driver reads a status word, and 0 is a MEANING in most protocols -- typically "waiting"
    /// or "standby". Publishing the struct default therefore reports a device at full power as
    /// idle, with the Modbus validity bit set to say you may believe it. When false, outputs
    /// publish null (review, 2026-07-25).
    bool statusCodeSupported = false;
    /// Human-readable status. A driver that cannot map its raw status code to text must say
    /// so ("Unknown (<n>)") rather than guess at a meaning.
    std::string statusText;

    /// 32-bit: some protocols report a 32-bit fault bitmask; truncating it would silently
    /// drop the upper faults. The 16-bit Modbus register saturates instead (register_map.cpp).
    uint32_t errorCode = 0;
    /// Not every protocol exposes a readable error code. When false, outputs must publish
    /// null rather than 0, because 0 would assert "no fault" -- a claim we cannot make.
    bool errorCodeSupported = false;

    /// Applies the outcome of a poll attempt. The only place the online/stale rules live.
    void recordPollSuccess(uint64_t nowMs, const StalenessPolicy& policy);
    void recordPollFailure(uint64_t nowMs, const StalenessPolicy& policy);
};

}  // namespace heliograph
